import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class CompetitionTests {

    @Test
    public void testDijkstraConstructor() {

        //TODO
    }

    @Test
    public void testFWConstructor() {
        //TODO
    }

    //TODO - more tests
    
}